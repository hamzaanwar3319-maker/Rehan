GITHUB CLOUD BUILD KIT (Windows EXE)\n

This kit contains the GitHub Actions workflow that builds the Windows installer on a hosted Windows runner.


IMPORTANT: You must add this workflow to the Marketplace Bot project root, alongside its desktop folder.

Steps:
1) Extract your existing marketplace-bot project ZIP.
2) In the extracted project root, create the folders: .github/workflows
3) Copy build-windows.yml into .github/workflows/
4) Upload the complete project (including the .github folder and desktop folder) to a GitHub repository.
   GitHub: https://github.com/new
5) Open the repository -> Actions tab -> select "Build Marketplace Bot Admin for Windows".
6) Click "Run workflow" and confirm.
7) Wait for the workflow to finish. Open the successful run and download the artifact named
   "Marketplace-Bot-Admin-Windows-Installer" from the bottom of the run page.
   The artifact ZIP contains the Setup.exe.

The workflow only builds the existing admin project. It does not add Facebook posting automation.
This workflow is configured for desktop/ and npm run build:win. If the project structure/scripts differ,
GitHub Actions may fail and the error log will be needed to adjust it.
